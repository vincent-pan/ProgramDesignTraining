package com.gs.son;

import com.gs.InFa.CatchMouse;
import com.gs.father.Pet;

public class Cat extends Pet implements CatchMouse{

	public Cat(String nickname, int age) {
		super(nickname, age);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void show() {
		// TODO Auto-generated method stub
		super.show();
	}

	@Override
	public void say() {
		// TODO Auto-generated method stub
		System.out.println("miaomiao");
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("cat run");
	}

	@Override
	public void catchMouse() {
		// TODO Auto-generated method stub
		System.out.println("i can catch mouse");
	}


	

}
