package com.gs.son;

import com.gs.InFa.Swim;
import com.gs.father.Pet;

public class Dog extends Pet implements Swim{

	public Dog(String nickname, int age) {
		
		super(nickname, age);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void say() {
		// TODO Auto-generated method stub
		System.out.println("wangwangwang");
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("dog run");
	}

	@Override
	public void show() {
		// TODO Auto-generated method stub
		super.show();
	}

	@Override
	public void swim() {
		// TODO Auto-generated method stub
		System.out.println("i can swim");
	}


}
