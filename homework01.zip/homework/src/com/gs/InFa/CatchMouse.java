package com.gs.InFa;

public interface CatchMouse {
	public void catchMouse();
}
