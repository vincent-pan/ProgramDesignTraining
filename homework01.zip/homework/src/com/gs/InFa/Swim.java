package com.gs.InFa;

public interface Swim {
	public void swim();
}
