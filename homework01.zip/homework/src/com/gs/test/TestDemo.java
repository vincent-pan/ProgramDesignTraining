package com.gs.test;

import com.gs.father.Pet;
import com.gs.son.Cat;
import com.gs.son.Dog;

public class TestDemo {
public static void main(String[] args) {
	Dog dog1 = new Dog("xiaobai",11);
	Cat cat1 = new Cat("xiaohui",2);
	Dog dog2 = new Dog("xiaohong",2);
	Cat cat2 = new Cat("xiaoxiao",3);
	Pet[] pet = {cat2,dog1,dog2,cat1};
	for(Pet pet1:pet) {
		pet1.show();
		pet1.say();
	}
	GirlFriend gf = new GirlFriend();
	gf.accept(dog1);
}
}
