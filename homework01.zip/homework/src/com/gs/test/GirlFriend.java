package com.gs.test;

import com.gs.father.Pet;
import com.gs.son.Cat;
import com.gs.son.Dog;

public class GirlFriend {
	public void accept(Pet pet) {
		if (pet instanceof Cat)
			((Cat) pet).catchMouse();
		if (pet instanceof Dog)
			((Dog) pet).swim();
		
	}
}
